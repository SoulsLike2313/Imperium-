# SECOND BRAIN MEMORY SUMMARY

**Generated:** 2026-05-15T23:46:44.310027
**Memory Root:** `E:\IMPERIUM\IMPERIUM_TEST_VERSION\SECOND_BRAIN`

---

## Files Status

| File | Exists | Size |
|------|--------|------|
| goals | ✅ | 1617 bytes |
| rules | ✅ | 1990 bytes |
| constraints | ✅ | 1609 bytes |
| errors | ✅ | 1188 bytes |
| context | ✅ | 1433 bytes |
| profile | ✅ | 894 bytes |
| queries | ✅ | 1518 bytes |

---

## Statistics

- **total_goals:** 6
- **critical_goals:** 2
- **total_rules:** 10
**rules_by_category:**
  - git: 3
  - paths: 1
  - output: 2
  - ui_work: 2
  - testing: 1
  - naming: 1
- **total_forbidden_actions:** 8
- **total_known_errors:** 5
- **predefined_queries:** 8
- **saved_answers:** 0

---

## Key Items

### Goals
- Build runnable prototypes, not scaffolds
- No fake PASS
- Receipts and reports for every action
- Dashboards show real data
- Test version isolation

### Rules
- No commit without Owner approval
- No push without Owner approval
- No merge without Owner approval
- Work only inside IMPERIUM_TEST_VERSION
- Create receipt for every significant action

### Forbidden Actions
- git commit
- git push
- git merge
- Modify files outside IMPERIUM_TEST_VERSION
- Delete main repo files

### Known Errors
- raw subprocess usage
- warning flood from continuity packs
- mojibake/encoding issues
- stale dashboard HEAD
- fake PASS without evidence
