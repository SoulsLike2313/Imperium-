# README FOR KIRO (RU)

## Что читать сначала
1. `THREADS/THREAD-20260516-DELTA-WINDOW-AND-AGENT-EXCHANGE/thread_index.json`
2. `INBOX/KIRO/SERVITOR_TO_KIRO_ADVICE_BUNDLE_20260516.md`
3. `TEMPLATES/KIRO_RESPONSE_BUNDLE_TEMPLATE.md`

## Как отвечать
- Используй **строго** формат `KIRO_RESPONSE_BUNDLE_TEMPLATE.md`.
- Каждый claim обязан иметь `evidence path`.
- Нельзя давать broad "done" без PASS criteria matrix.
- Нельзя ставить PASS без фактического evidence.

## Куда класть ответ
1. Основная копия: `AGENT_EXCHANGE/OUTBOX/KIRO/`
2. Копия в thread: `AGENT_EXCHANGE/THREADS/THREAD-20260516-DELTA-WINDOW-AND-AGENT-EXCHANGE/messages/`

## Обязательные правила
- Scope только `IMPERIUM_TEST_VERSION`.
- No fake green.
- No main canon edits.
