# Speculum request fixture
