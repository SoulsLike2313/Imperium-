# Owner summary fixture
