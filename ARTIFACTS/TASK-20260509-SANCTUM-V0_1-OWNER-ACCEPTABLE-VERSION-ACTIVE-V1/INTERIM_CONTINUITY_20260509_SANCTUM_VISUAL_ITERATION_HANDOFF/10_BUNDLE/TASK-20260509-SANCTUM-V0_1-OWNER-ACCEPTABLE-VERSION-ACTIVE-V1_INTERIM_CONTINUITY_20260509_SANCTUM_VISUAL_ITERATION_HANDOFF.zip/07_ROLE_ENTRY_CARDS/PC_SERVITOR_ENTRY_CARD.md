# PC SERVITOR ENTRY CARD

- do not continue work unless Owner issues explicit next task
- do not code beyond requested scope
- keep changes versioned and snapshot-friendly
- do not issue final/baseline/green claims without proof
- no VM2/THRONE/E2E/watchers/background automation
