# STAGE_ID Mismatch Scan Report

task_id: TASK-20260509-0014F-PREPATCH-STAGE-ID-SCHEMA-MISMATCH-V1
generated_at_utc: 2026-05-09T07:52:20Z
files_scanned_count: 1640
files_with_stage_id_mentions_count: 377

## Scan Scope
- active_root: e:\IMPERIUM\SSH_COMMAND_LIBRARY\06_TOOLS
- historical_root: e:\IMPERIUM\ARTIFACTS
- historical_max_depth: 4
- excluded_tokens: __pycache__, .git, VERIFY_EXTRACT, FINAL_BUNDLE_EXTRACT_CHECK, CLEANHASH_VERIFY_EXTRACT, TOOL_SNAPSHOT, PATCH_SNAPSHOT

## Pattern Counts
- STAGE-PC-001: matches=259, files=36
- STAGE-VM2-001: matches=42, files=8
- PC-STAGE-001: matches=225, files=35
- VM2-STAGE-001: matches=91, files=16
- stage_id: matches=5521, files=328
- STAGE_ID: matches=95, files=74

## Scope Classification
- active_hits_count: 43
- historical_hits_count: 334
- other_hits_count: 0

## Active Mismatch Candidates
- NONE

## Legacy References
- legacy_stage_id_files_count: 37
- Historical legacy values are marked as LEGACY_STAGE_ID_FORMAT and not rewritten.

## Key Active Files
- SSH_COMMAND_LIBRARY/06_TOOLS/01_CORE_LIB/id_validation.py
- SSH_COMMAND_LIBRARY/06_TOOLS/01_CORE_LIB/ledger_utils.py
- SSH_COMMAND_LIBRARY/06_TOOLS/01_CORE_LIB/manifest_utils.py
- SSH_COMMAND_LIBRARY/06_TOOLS/01_CORE_LIB/provenance_utils.py
- SSH_COMMAND_LIBRARY/06_TOOLS/10_PC_VM2_PIPELINE/README.md
- SSH_COMMAND_LIBRARY/06_TOOLS/10_PC_VM2_PIPELINE/barrier_verify.py
- SSH_COMMAND_LIBRARY/06_TOOLS/10_PC_VM2_PIPELINE/examples/README.md
- SSH_COMMAND_LIBRARY/06_TOOLS/10_PC_VM2_PIPELINE/examples/send_prompt_example.ps1
- SSH_COMMAND_LIBRARY/06_TOOLS/10_PC_VM2_PIPELINE/fetch_vm2_stage_bundle.py
- SSH_COMMAND_LIBRARY/06_TOOLS/10_PC_VM2_PIPELINE/final_bundle_assemble.py
- SSH_COMMAND_LIBRARY/06_TOOLS/10_PC_VM2_PIPELINE/send_prompt_to_vm2.py
- SSH_COMMAND_LIBRARY/06_TOOLS/10_PC_VM2_PIPELINE/task_status_append.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/artifact_manifest_verify.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/inquisition_trace_audit.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/ledger_replay_verify.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/lib/common_runtime.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_coordination_view.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_dependency_check.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_gate_decide.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_heartbeat_emit.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_plan_read.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_repair_request.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_signal_ack.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_signal_verify.py
- SSH_COMMAND_LIBRARY/06_TOOLS/15_STAGE_COORDINATION/stage_wait_for_signal.py
- SSH_COMMAND_LIBRARY/06_TOOLS/20_CONTINUITY/continuity_scan_known_blockers.py
- SSH_COMMAND_LIBRARY/06_TOOLS/20_CONTINUITY/continuity_scan_receipts.py
- SSH_COMMAND_LIBRARY/06_TOOLS/STAGE_ID_POLICY.json
- SSH_COMMAND_LIBRARY/06_TOOLS/STAGE_ID_POLICY.md
- SSH_COMMAND_LIBRARY/06_TOOLS/fetch_vm2_stage_bundle.py
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/SCRIPT_USAGE_EXAMPLES.md
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/barrier_verify.py
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/examples/send_prompt_example.ps1
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/fetch_vm2_stage_bundle.py
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/final_bundle_assemble.py
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/lib/id_validation.py
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/lib/ledger_utils.py
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/lib/manifest_utils.py
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/lib/provenance_utils.py
- SSH_COMMAND_LIBRARY/06_TOOLS/imperium_pipeline/send_prompt_to_vm2.py
- ... (+3 more in JSON report)
