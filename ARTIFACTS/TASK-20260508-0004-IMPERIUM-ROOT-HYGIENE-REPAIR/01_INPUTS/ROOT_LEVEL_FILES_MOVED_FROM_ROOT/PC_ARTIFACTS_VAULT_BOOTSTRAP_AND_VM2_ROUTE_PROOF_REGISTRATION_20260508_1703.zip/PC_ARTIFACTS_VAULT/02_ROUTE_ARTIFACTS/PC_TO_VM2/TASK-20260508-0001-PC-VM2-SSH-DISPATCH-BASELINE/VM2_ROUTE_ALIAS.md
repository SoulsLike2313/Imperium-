# VM2_ROUTE_ALIAS

Route alias: PC_TO_VM2_PROMPT_DISPATCH_V1

Маршрут используется только для ручной отправки prompt/task package с PC на VM2 в назначенную папку TASK_ID.
