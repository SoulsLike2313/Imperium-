# SOURCE POINTER

artifact_id:
ARTIFACT-20260508-0001-VM2-ROUTE-PROOF

source_library:
SSH_COMMAND_LIBRARY

source_zip_path:
E:\IMPERIUM\SSH_COMMAND_LIBRARY\VM2_ROUTE_BASELINE_20260508_1651.zip

vault_copy_path:
E:\IMPERIUM\PC_ARTIFACTS_VAULT\02_ROUTE_ARTIFACTS\PC_TO_VM2\TASK-20260508-0001-PC-VM2-SSH-DISPATCH-BASELINE\VM2_ROUTE_BASELINE_20260508_1651.zip

sha256:
fb49caff946f43fc5178f0bf3f5c4393f279ee3f4fa4935a3076781add53477e

relationship:
Original route proof remains in SSH_COMMAND_LIBRARY.
PC_ARTIFACTS_VAULT stores evidence copy and registry entry.

canon_status:
NOT CANON

admission_status:
NOT ADMISSION

notes:
This record is only proof that PC→VM2 prompt dispatch baseline was tested and registered.
