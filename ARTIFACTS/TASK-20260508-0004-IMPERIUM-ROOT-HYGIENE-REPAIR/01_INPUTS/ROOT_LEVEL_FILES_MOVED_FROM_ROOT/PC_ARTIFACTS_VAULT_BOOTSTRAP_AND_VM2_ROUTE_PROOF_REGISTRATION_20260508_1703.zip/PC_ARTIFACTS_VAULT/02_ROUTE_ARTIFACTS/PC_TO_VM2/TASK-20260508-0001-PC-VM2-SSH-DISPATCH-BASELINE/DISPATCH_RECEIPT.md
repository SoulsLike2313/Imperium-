# DISPATCH_RECEIPT

task_id: TASK-20260508-0001-PC-VM2-SSH-DISPATCH-BASELINE
stage_id: STAGE-001-VM2-RECEIVE-PROMPT-SMOKE
run_id: RUN-20260508-0001
contour_from: PC
contour_to: VM2
route_id: PC_TO_VM2_PROMPT_DISPATCH_V1
local_prompt_path: E:\IMPERIUM\SSH_COMMAND_LIBRARY\VM2_ROUTE_BASELINE_20260508_1651\03_SMOKE_TEST_PROMPT_DISPATCH\PROMPT.txt
remote_prompt_path: /home/vboxuser2/IMPERIUM_WORKER_ROOM/INBOX/tasks/TASK-20260508-0001-PC-VM2-SSH-DISPATCH-BASELINE/PROMPT.txt
local_sha256: 69ad97784c0a62d72da61e15c2ec5dc4e5507ee8fc8edc90e1e2af51bf421c43
remote_sha256: 69ad97784c0a62d72da61e15c2ec5dc4e5507ee8fc8edc90e1e2af51bf421c43
sha256_match: YES
created_remote_dirs: /home/vboxuser2/IMPERIUM_WORKER_ROOM; /home/vboxuser2/IMPERIUM_WORKER_ROOM/INBOX; /home/vboxuser2/IMPERIUM_WORKER_ROOM/INBOX/tasks; /home/vboxuser2/IMPERIUM_WORKER_ROOM/INBOX/tasks/TASK-20260508-0001-PC-VM2-SSH-DISPATCH-BASELINE
commands_redacted: YES
secrets_included: NO
throne_touched: NO
vm3_touched: NO
delete_performed: NO
autosync_used: NO
latest_bundle_used: NO
verdict: PASS
notes: Smoke-test completed.
