# VM2_WORKING_PATHS

- Local output folder: E:\IMPERIUM\SSH_COMMAND_LIBRARY\VM2_ROUTE_BASELINE_20260508_1651
- Remote worker root: ~/IMPERIUM_WORKER_ROOM
- Remote task inbox: ~/IMPERIUM_WORKER_ROOM/INBOX/tasks
- Exact remote test task path: ~/IMPERIUM_WORKER_ROOM/INBOX/tasks/TASK-20260508-0001-PC-VM2-SSH-DISPATCH-BASELINE

Эти пути не являются THRONE и не являются canon.
