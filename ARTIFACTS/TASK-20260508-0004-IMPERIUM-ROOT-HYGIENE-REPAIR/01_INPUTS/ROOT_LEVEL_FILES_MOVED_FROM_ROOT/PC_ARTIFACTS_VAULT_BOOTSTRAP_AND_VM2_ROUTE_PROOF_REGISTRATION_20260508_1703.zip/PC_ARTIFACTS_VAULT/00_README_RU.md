# PC_ARTIFACTS_VAULT

PC_ARTIFACTS_VAULT = доказательная память PC-контура.

- Это не THRONE.
- Это не canon.
- Это не admission authority.
- Здесь хранятся receipts, bundles, manifests, sha256, owner summaries, route proofs, stage proofs.
- Инструменты остаются в профильных библиотеках.
- Доказательства применения инструментов регистрируются здесь.
