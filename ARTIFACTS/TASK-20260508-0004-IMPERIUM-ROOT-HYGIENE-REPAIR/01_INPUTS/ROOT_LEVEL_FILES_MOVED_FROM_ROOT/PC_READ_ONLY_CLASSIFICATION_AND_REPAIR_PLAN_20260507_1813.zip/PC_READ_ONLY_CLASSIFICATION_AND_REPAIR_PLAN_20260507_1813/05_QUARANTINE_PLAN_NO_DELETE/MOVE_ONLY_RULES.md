# MOVE ONLY RULES

Перед move требуется:
- source path
- target quarantine path
- sha256
- size
- reason
- owner approval marker

Delete запрещен.