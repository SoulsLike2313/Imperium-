# OPTIONAL PURGE LATER POLICY

Purge возможен только в отдельной фазе после двойной верификации и owner sign-off.