# QUARANTINE PLAN (NO DELETE)

План только move-only после owner approval.
Текущий документ не выполняет перемещение.
Все источники остаются на месте.