# THRONE CONTAMINATION REPORT

- payload files scanned: 2141
- blockers found: 965
- allowed canon candidates: 1120

Статус: текущий payload считается CONTAMINATED для прямого transfer.