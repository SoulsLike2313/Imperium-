# THRONE CANDIDATE V2 REQUIREMENTS

1. Полная классификация всех файлов payload.
2. Полное исключение runtime/state/log/pyc/zip/review_artifacts.
3. Полное исключение local config и локальных endpoint snapshots.
4. Исключение worker-specific residue.
5. Manifest + checksums + owner review gate.
6. Admission только после owner approval.