# CLASSIFICATION SUMMARY

Всего файлов: 27270
SECRET_OR_LOCAL_ENDPOINT: 5112
UNKNOWN_REVIEW_REQUIRED: 5259

Правило блокировки: все UNKNOWN_REVIEW_REQUIRED и все runtime/staging/bundle/receipt/evidence/local_config/secret_worker-specific блокируются от THRONE transfer.