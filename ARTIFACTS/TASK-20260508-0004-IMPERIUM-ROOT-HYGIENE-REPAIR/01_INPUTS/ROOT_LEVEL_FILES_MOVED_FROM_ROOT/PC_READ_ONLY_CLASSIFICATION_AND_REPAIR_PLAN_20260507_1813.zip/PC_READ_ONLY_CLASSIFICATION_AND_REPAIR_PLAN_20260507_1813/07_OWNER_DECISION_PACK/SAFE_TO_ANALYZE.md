# SAFE TO ANALYZE

Все локальные surfaces доступны для read-only анализа и дальнейшей классификации.