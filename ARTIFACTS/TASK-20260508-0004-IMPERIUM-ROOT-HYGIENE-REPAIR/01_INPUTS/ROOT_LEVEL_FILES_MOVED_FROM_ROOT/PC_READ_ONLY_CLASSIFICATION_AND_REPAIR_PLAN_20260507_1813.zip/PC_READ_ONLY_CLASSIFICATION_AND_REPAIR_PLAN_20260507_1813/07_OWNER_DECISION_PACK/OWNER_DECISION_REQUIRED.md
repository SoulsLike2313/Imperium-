# OWNER DECISION REQUIRED

Требуется owner approval по:
- quarantine manifest draft
- THRONE exclusions draft
- VM generic template blockers
- secret/local endpoint confirmed blockers