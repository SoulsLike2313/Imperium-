# NOT SAFE TO USE FOR VM2

VM3-specific residue, hardcoded endpoints, runtime/state/log surfaces и local configs блокируют reuse.