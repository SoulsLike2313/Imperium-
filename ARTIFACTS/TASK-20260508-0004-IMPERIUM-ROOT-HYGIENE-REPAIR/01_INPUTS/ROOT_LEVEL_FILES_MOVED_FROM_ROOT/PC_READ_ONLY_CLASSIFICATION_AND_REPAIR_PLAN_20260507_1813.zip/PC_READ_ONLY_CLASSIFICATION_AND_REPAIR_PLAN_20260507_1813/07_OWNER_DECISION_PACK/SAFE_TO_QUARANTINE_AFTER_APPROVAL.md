# SAFE TO QUARANTINE AFTER APPROVAL

Только файлы из QUARANTINE_MANIFEST_DRAFT.csv и только move-only.