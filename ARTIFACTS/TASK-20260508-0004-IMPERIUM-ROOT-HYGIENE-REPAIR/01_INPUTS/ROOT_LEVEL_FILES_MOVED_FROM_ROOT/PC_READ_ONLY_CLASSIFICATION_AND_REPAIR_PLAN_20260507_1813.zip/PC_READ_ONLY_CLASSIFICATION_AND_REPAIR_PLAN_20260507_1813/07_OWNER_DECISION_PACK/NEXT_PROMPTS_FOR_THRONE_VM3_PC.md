# NEXT PROMPTS FOR THRONE VM3 PC

1. Prompt: owner review of THRONE exclusions manifest.
2. Prompt: build THRONE_CANDIDATE_V2 from allowed-only list.
3. Prompt: build VM_WORKER_TEMPLATE_V1 from allowed-only list.
4. Prompt: execute move-only quarantine after approval.