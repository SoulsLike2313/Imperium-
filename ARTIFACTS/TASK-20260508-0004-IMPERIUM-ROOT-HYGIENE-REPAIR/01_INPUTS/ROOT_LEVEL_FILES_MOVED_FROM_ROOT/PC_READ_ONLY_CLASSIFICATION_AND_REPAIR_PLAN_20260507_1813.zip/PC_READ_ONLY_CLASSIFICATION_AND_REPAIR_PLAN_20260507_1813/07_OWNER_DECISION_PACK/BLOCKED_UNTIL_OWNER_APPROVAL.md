# BLOCKED UNTIL OWNER APPROVAL

Transfer to THRONE и использование для VM2 остаются заблокированы до owner approval.