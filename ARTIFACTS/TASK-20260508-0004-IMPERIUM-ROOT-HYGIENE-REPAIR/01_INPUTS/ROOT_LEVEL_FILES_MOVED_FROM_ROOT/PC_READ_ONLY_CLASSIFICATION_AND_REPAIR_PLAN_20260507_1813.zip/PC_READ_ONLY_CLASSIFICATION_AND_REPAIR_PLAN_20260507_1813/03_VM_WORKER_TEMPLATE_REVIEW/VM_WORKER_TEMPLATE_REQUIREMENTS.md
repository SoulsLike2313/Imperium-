# VM WORKER TEMPLATE REQUIREMENTS

Template должен содержать только reusable SOURCE_CODE/APPROVED_OPERATION/DOCS/CANON.
Все VM3-specific runtime/live-state/hardcoded endpoints должны быть исключены.
Все маршруты и endpoints только через параметризацию placeholders.