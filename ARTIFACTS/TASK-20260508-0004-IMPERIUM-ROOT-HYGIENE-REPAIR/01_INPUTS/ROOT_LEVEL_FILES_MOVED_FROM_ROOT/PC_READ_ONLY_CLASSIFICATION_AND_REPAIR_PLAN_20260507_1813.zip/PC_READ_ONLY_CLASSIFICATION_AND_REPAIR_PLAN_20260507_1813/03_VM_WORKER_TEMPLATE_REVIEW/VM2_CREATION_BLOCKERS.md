# VM2 CREATION BLOCKERS

1. Наличие hardcoded VM3 endpoints.
2. Наличие worker-specific residue.
3. Наличие runtime/live-state файлов.
4. Наличие local config/secret hits.