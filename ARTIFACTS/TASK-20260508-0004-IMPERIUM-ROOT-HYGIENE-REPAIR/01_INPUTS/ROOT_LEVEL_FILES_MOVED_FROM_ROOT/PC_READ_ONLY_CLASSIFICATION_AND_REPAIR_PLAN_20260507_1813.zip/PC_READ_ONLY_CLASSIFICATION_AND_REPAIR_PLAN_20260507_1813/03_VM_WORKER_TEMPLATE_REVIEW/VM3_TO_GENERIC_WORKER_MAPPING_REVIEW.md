# VM3 TO GENERIC WORKER MAPPING REVIEW

VM3 scripts делятся на:
- reusable core logic (оставить);
- environment-bound transport/config (параметризовать);
- runtime/state/history debris (исключить).