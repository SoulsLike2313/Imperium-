# SECRET REDACTION POLICY

1. No raw password/token/api_key in canon candidate.
2. No private key paths in THRONE payload.
3. No local endpoint snapshots in THRONE candidate.
4. Config templates allowed; raw local values blocked.
5. Local runtime config lives on PC only.