# PC OBSERVABILITY STRUCTURE REPAIR PLAN

Развести runtime evidence и candidate surfaces в разные верхнеуровневые зоны.
Сделать единый реестр bundles/receipts с lifecycle статусами.
Убрать дубли candidate paths и зафиксировать один source-of-review.