# THRONE CANDIDATE V2 REPAIR PLAN

Можно включать: CANON + APPROVED_OPERATION + SOURCE_CODE + DOCS (после review).
Нельзя включать: runtime/state/log/staging/bundle/history/local_config/secret/worker_specific/unknown.
Нужны gates: classification gate -> exclusions gate -> checksum gate -> owner gate.
Только после owner решения формировать новый payload.