# BUNDLE_LAW_V1

Каждый worker bundle обязан содержать:
- archive.zip
- archive.sha256
- MANIFEST.json
- CHANGELOG.md
- RUN_INSTRUCTIONS.md
- TEST_INSTRUCTIONS.md
- RISK_REPORT.md
- FILES_CHANGED.csv
- EXCLUSIONS.md
- WORKER_RECEIPT.txt