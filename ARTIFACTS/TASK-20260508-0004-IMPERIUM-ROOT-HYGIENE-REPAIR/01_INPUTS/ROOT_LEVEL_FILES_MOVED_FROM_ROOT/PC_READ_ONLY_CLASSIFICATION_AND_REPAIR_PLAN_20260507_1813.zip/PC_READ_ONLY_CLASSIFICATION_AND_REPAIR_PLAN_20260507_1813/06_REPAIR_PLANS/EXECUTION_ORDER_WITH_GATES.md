# EXECUTION ORDER WITH GATES

1. Classification gate (complete and reviewed).
2. Secret/local config gate.
3. THRONE contamination exclusion gate.
4. VM generic template gate.
5. Owner decision gate.
6. Optional quarantine move-only gate.
7. Separate build of new candidates (outside this read-only phase).