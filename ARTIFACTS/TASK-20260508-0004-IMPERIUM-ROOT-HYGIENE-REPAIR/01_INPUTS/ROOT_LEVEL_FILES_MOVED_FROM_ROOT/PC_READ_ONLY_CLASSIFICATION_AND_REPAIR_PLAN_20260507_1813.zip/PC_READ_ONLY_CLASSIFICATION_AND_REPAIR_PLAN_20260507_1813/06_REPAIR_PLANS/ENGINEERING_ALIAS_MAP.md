# ENGINEERING ALIAS MAP

- THRONE = canonical repository / source of truth
- PC / Servik = owner operations center / review bench
- VM worker = disposable execution contour
- Officio Agentis = agent role governance
- Custodes = admission gate / canon guard
- Inquisition = contradiction / drift detection
- Mechanicus = technical validation / runtime proof
- Administratum = registry / inventory / memory surface
- Speculum / Logos = adversarial reviewer / owner-facing analyst