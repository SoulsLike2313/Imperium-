# VM WORKER TEMPLATE V1 REPAIR PLAN

1. Вырезать VM3-specific residue и live-state surfaces.
2. Параметризовать endpoints и identity placeholders.
3. Переписать transport scripts в generic worker mode.
4. Отдельно прогнать security/config gate.
5. Только затем использовать для создания VM2.