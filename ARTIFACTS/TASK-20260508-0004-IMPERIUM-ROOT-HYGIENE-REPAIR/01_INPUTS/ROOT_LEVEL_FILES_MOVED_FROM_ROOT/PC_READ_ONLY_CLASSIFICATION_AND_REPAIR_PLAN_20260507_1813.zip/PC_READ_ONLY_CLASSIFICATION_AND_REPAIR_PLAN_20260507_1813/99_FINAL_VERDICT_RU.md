# FINAL VERDICT

- scanned_files: 27270
- throne_payload_files: 2141
- throne_blockers: 965
- vm_template_blocked: 1237
- secret_hits: 8285

THRONE transfer status: BLOCKED
VM2 usage status: BLOCKED

This package is read-only classification + quarantine plan + repair plan only.