# IMPERIUM Light Snapshot

Generated at: 2026-05-07 16:45:08 +03:00
Snapshot folder: E:\IMPERIUM\IMPERIUM_LIGHT_SNAPSHOT_20260507_164459

Scope roots: OBSERVED, PC_OWNER_TEST_BENCH, PROMPT_OUTBOX_TO_VM3, SSH_COMMAND_LIBRARY

## Root Stats
| Root | Path | Files | Dirs | Size GB |
|---|---|---:|---:|---:|
| OBSERVED | E:\IMPERIUM\OBSERVED | 23801 | 4329 | 2.151 |
| PC_OWNER_TEST_BENCH | E:\IMPERIUM\PC_OWNER_TEST_BENCH | 21 | 13 | 0.001 |
| PROMPT_OUTBOX_TO_VM3 | E:\IMPERIUM\PROMPT_OUTBOX_TO_VM3 | 46 | 30 | 0 |
| SSH_COMMAND_LIBRARY | E:\IMPERIUM\SSH_COMMAND_LIBRARY | 11 | 9 | 0 |

## Notes
- This is a lightweight metadata snapshot, not a full binary mirror.
- For OBSERVED only hash proofs are copied into samples to avoid duplicating large archives.
- Full file inventories and trees are in 'inventories/' and 'trees/'.
