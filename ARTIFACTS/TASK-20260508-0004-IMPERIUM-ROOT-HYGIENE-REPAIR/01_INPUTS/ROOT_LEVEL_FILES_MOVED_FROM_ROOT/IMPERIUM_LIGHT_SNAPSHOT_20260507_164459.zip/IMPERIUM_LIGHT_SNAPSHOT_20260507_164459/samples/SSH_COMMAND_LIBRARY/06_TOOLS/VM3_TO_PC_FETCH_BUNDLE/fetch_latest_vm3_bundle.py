import subprocess
import hashlib
import shlex
from pathlib import Path
from datetime import datetime


SSH_USERHOST = "vboxuser3@127.0.0.1"
SSH_PORT = "2225"
SSH_KEY = Path.home() / ".ssh" / "imperium_pc_to_vm3_ed25519_20260418"

REMOTE_OUTPUTS = "/home/vboxuser3/Desktop/IMPERIUM_STAGING/bridge_exchange/current_task_outputs"

LOCAL_INBOX = Path(r"E:\IMPERIUM\PC_OWNER_TEST_BENCH\00_INBOX_FROM_VM3")
LOCAL_RECEIPTS = Path(r"E:\IMPERIUM\PC_OWNER_TEST_BENCH\04_RECEIPTS")
RECIPE_FILE = Path(r"E:\IMPERIUM\SSH_COMMAND_LIBRARY\05_SUCCESSFUL_RECIPES\VM3_TO_PC_FETCH_LATEST_BUNDLE_TESTED_OK.md")


def run(cmd: list[str]) -> str:
    print("RUN:", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("STDOUT:", result.stdout)
        print("STDERR:", result.stderr)
        raise RuntimeError("Command failed")
    return result.stdout.strip()


def ssh(command: str) -> str:
    return run([
        "ssh",
        "-i", str(SSH_KEY),
        "-p", SSH_PORT,
        SSH_USERHOST,
        command
    ])


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_recipe():
    RECIPE_FILE.parent.mkdir(parents=True, exist_ok=True)
    text = f"""# VM3 -> PC Fetch Latest Bundle

Status: TESTED_OK_CANDIDATE
Date: {datetime.now().strftime("%Y-%m-%d")}

Purpose:
Fetch the latest .zip bundle from VM3 current_task_outputs to PC inbox.

VM3 source:
{REMOTE_OUTPUTS}

PC target:
{LOCAL_INBOX}

SSH:
userhost: {SSH_USERHOST}
port: {SSH_PORT}
identity file: {SSH_KEY}

Behavior:
1. Finds newest *.zip in VM3 current_task_outputs.
2. Computes remote sha256.
3. Copies zip to PC inbox.
4. Computes local sha256.
5. Writes receipt.
6. Opens PC inbox in Explorer.

Rules:
- Fetch only.
- No delete.
- No remote mutation.
- No admission.
- PC inbox is review intake only, not canon.

Verdict:
VM3_TO_PC_FETCH_LATEST_BUNDLE route is usable after sha256 MATCH=True.
"""
    RECIPE_FILE.write_text(text, encoding="utf-8")


def main():
    if not SSH_KEY.exists():
        raise FileNotFoundError(f"SSH key not found: {SSH_KEY}")

    LOCAL_INBOX.mkdir(parents=True, exist_ok=True)
    LOCAL_RECEIPTS.mkdir(parents=True, exist_ok=True)

    write_recipe()

    find_cmd = (
        f"find {shlex.quote(REMOTE_OUTPUTS)} "
        f"-maxdepth 1 -type f -name '*.zip' -printf '%T@ %f\\n' "
        f"| sort -nr | head -n 1"
    )

    latest_line = ssh(find_cmd)

    if not latest_line:
        raise FileNotFoundError("No .zip bundle found in VM3 current_task_outputs")

    _, zip_name = latest_line.split(maxsplit=1)

    remote_zip = f"{REMOTE_OUTPUTS}/{zip_name}"
    local_zip = LOCAL_INBOX / zip_name

    remote_hash = ssh(f"sha256sum {shlex.quote(remote_zip)} | cut -d ' ' -f1").strip().lower()

    run([
        "scp",
        "-i", str(SSH_KEY),
        "-P", SSH_PORT,
        f"{SSH_USERHOST}:{remote_zip}",
        str(local_zip)
    ])

    local_hash = sha256_file(local_zip).lower()
    match = local_hash == remote_hash

    receipt_file = LOCAL_RECEIPTS / f"FETCH_{Path(zip_name).stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.receipt.txt"

    receipt = f"""FETCH_LATEST_VM3_BUNDLE_RECEIPT

STATUS=FETCHED
MATCH={match}
REMOTE_ZIP={remote_zip}
LOCAL_ZIP={local_zip}
REMOTE_SHA256={remote_hash}
LOCAL_SHA256={local_hash}
FETCHED_AT={datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
SSH_USERHOST={SSH_USERHOST}
SSH_PORT={SSH_PORT}
SSH_KEY={SSH_KEY}
"""

    receipt_file.write_text(receipt, encoding="utf-8")

    subprocess.Popen(["explorer", str(LOCAL_INBOX)])

    print()
    print("FETCH COMPLETE")
    print("REMOTE:", remote_zip)
    print("LOCAL:", local_zip)
    print("MATCH:", match)
    print("RECEIPT:", receipt_file)
    print("RECIPE:", RECIPE_FILE)
    print()


if __name__ == "__main__":
    main()