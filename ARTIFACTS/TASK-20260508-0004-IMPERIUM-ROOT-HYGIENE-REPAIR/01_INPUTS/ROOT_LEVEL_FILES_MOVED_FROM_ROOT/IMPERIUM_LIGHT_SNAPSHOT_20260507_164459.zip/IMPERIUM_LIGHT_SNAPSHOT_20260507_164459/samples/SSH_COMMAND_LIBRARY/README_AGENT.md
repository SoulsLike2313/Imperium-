# IMPERIUM SSH Command Library

Status: TESTED_WORKING

Purpose:
This folder stores tested SSH/SCP routes, scripts, recipes, and machine-readable contracts for PC <-> VM3 handoff.

Start here:
1. 00_MACHINE_README.json
2. 06_TOOLS/*/TOOL_MANIFEST.json
3. 05_SUCCESSFUL_RECIPES/

Main routes:

## PC_TO_VM3_PROMPT_HANDOFF

Entrypoint:
06_TOOLS\PC_TO_VM3_PROMPT_HANDOFF\SEND_LATEST_DRAFT_TO_VM3.py

Purpose:
Take latest .txt draft from:
E:\IMPERIUM\PROMPT_OUTBOX_TO_VM3\00_DRAFTS

Send it to VM3 as:
current_task_inputs/<STEP_ID>/PROMPT.txt

Then open PROMPT.txt on VM3 for manual copy into Codex/Servik.

## VM3_TO_PC_FETCH_LATEST_BUNDLE

Entrypoint:
06_TOOLS\VM3_TO_PC_FETCH_BUNDLE\fetch_latest_vm3_bundle.py

Purpose:
Fetch latest .zip bundle from VM3 current_task_outputs to:
E:\IMPERIUM\PC_OWNER_TEST_BENCH\00_INBOX_FROM_VM3

Then verify sha256 and open the PC inbox.

Safety:
- This library does not perform admission.
- This library does not mutate THRONE.
- This library does not make PC canonical.
- This library must not contain secrets.
