import argparse
import hashlib
import os
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
import shlex


PC_ROOT = Path(r"E:\IMPERIUM\PROMPT_OUTBOX_TO_VM3")

READY_ROOT = PC_ROOT / "01_READY_TO_SEND"
SENT_ROOT = PC_ROOT / "02_SENT"
RECEIPT_ROOT = PC_ROOT / "03_RECEIPTS"

SSH_USERHOST = "vboxuser3@127.0.0.1"
SSH_PORT = "2225"
SSH_KEY = Path.home() / ".ssh" / "imperium_pc_to_vm3_ed25519_20260418"

REMOTE_ROOT = "/home/vboxuser3/Desktop/IMPERIUM_STAGING/bridge_exchange/current_task_inputs"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run(cmd: list[str]) -> str:
    print("RUN:", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("STDOUT:", result.stdout)
        print("STDERR:", result.stderr)
        raise RuntimeError(f"Command failed: {' '.join(cmd)}")
    return result.stdout.strip()


def safe_step_name(name: str) -> str:
    cleaned = []
    for ch in name:
        if ch.isalnum() or ch in "_-.":
            cleaned.append(ch)
        else:
            cleaned.append("_")
    return "".join(cleaned)


def main():
    parser = argparse.ArgumentParser(description="Send prompt file from PC to VM3 and open it there.")
    parser.add_argument("--prompt-file", required=True, help="Path to local prompt file")
    parser.add_argument("--step-name", required=True, help="Step name, e.g. VM3_SERVIK_DIFF_REVIEW")
    args = parser.parse_args()

    prompt_file = Path(args.prompt_file)

    if not prompt_file.exists():
        raise FileNotFoundError(f"Prompt file not found: {prompt_file}")

    if not SSH_KEY.exists():
        raise FileNotFoundError(f"SSH key not found: {SSH_KEY}")

    READY_ROOT.mkdir(parents=True, exist_ok=True)
    SENT_ROOT.mkdir(parents=True, exist_ok=True)
    RECEIPT_ROOT.mkdir(parents=True, exist_ok=True)

    step_id = f"{safe_step_name(args.step_name)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    local_step = READY_ROOT / step_id
    local_step.mkdir(parents=True, exist_ok=True)

    local_prompt = local_step / "PROMPT.txt"
    shutil.copy2(prompt_file, local_prompt)

    sent_step = SENT_ROOT / step_id
    receipt_file = RECEIPT_ROOT / f"{step_id}.receipt.txt"

    remote_step = f"{REMOTE_ROOT}/{step_id}"
    remote_prompt = f"{remote_step}/PROMPT.txt"

    local_hash = sha256_file(local_prompt)

    run([
        "ssh",
        "-i", str(SSH_KEY),
        "-p", SSH_PORT,
        SSH_USERHOST,
        f"mkdir -p {shlex.quote(remote_step)}"
    ])

    run([
        "scp",
        "-i", str(SSH_KEY),
        "-P", SSH_PORT,
        str(local_prompt),
        f"{SSH_USERHOST}:{remote_prompt}"
    ])

    remote_hash_output = run([
        "ssh",
        "-i", str(SSH_KEY),
        "-p", SSH_PORT,
        SSH_USERHOST,
        f"sha256sum {shlex.quote(remote_prompt)}"
    ])

    remote_hash = remote_hash_output.split()[0].lower()
    match = local_hash.lower() == remote_hash

    if sent_step.exists():
        shutil.rmtree(sent_step)
    shutil.copytree(local_step, sent_step)

    receipt_text = f"""STEP_ID={step_id}
STATUS=SENT_TO_VM3
MATCH={match}
LOCAL_PROMPT={local_prompt}
REMOTE_PROMPT={remote_prompt}
LOCAL_SHA256={local_hash}
REMOTE_SHA256={remote_hash}
SENT_AT={datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
SSH_USERHOST={SSH_USERHOST}
SSH_PORT={SSH_PORT}
SSH_KEY={SSH_KEY}
"""

    receipt_file.write_text(receipt_text, encoding="utf-8")

    run([
        "ssh",
        "-i", str(SSH_KEY),
        "-p", SSH_PORT,
        SSH_USERHOST,
        (
            f"DISPLAY=:0 XAUTHORITY=/home/vboxuser3/.Xauthority "
            f"xdg-open {shlex.quote(remote_prompt)} "
            f">/tmp/{step_id}_open.log 2>&1 & echo OPEN_SENT"
        )
    ])

    print()
    print("PROMPT SENT TO VM3")
    print("STEP_ID:", step_id)
    print("LOCAL:", local_prompt)
    print("REMOTE:", remote_prompt)
    print("MATCH:", match)
    print("RECEIPT:", receipt_file)
    print()


if __name__ == "__main__":
    main()