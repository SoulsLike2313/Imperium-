import subprocess
import sys
from pathlib import Path


BASE_ROOT = Path(r"E:\IMPERIUM\PROMPT_OUTBOX_TO_VM3")
DRAFTS_ROOT = BASE_ROOT / "00_DRAFTS"
SENDER = Path(__file__).resolve().parent / "send_prompt_to_vm3.py"


def main():
    if not DRAFTS_ROOT.exists():
        raise FileNotFoundError(f"Drafts folder not found: {DRAFTS_ROOT}")

    if not SENDER.exists():
        raise FileNotFoundError(f"Sender script not found: {SENDER}")

    drafts = sorted(
        DRAFTS_ROOT.glob("*.txt"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if not drafts:
        raise FileNotFoundError(f"No .txt drafts found in: {DRAFTS_ROOT}")

    latest = drafts[0]
    step_name = latest.stem

    print("LATEST DRAFT:", latest)
    print("STEP NAME:", step_name)
    print()

    cmd = [
        sys.executable,
        str(SENDER),
        "--prompt-file",
        str(latest),
        "--step-name",
        step_name,
    ]

    print("RUN:", " ".join(cmd))
    print()

    result = subprocess.run(cmd)

    if result.returncode != 0:
        raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()